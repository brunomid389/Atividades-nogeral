import 'package:flutter/material.dart';
import '../../widgets/app_button.dart';
import '../../utils/currency_formatter.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    double preco = 99.90;

    return Scaffold(
      appBar: AppBar(
        title: const Text("FlutterShop"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              formatarReal(preco),
              style: const TextStyle(fontSize: 24),
            ),
            const SizedBox(height: 20),
            AppButton(
              texto: "Adicionar ao Carrinho",
              onPressed: () {},
            ),
          ],
        ),
      ),
    );
  }
}
