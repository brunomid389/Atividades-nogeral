package com.example.fffa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
