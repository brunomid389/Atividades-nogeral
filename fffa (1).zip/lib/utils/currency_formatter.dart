String formatarReal(double valor) {
  return "R\$ ${valor.toStringAsFixed(2).replaceAll(".", ",")}";
}
