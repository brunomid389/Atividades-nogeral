import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("FlutterShop"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 1. Logo
            Padding(
              padding: const EdgeInsets.all(16),
              child: Image.asset(
                "assets/logo.png",
                width: 120,
              ),
            ),

            // 2. Banner
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              height: 150,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                image: const DecorationImage(
                  image: AssetImage("assets/banner.jpg"),
                  fit: BoxFit.cover,
                ),
              ),
            ),

            const SizedBox(height: 20),

            // 3. Foto de Perfil
            const CircleAvatar(
              radius: 45,
              backgroundImage: AssetImage("assets/perfil.jpg"),
            ),

            const SizedBox(height: 20),

            // 4. Produtos
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Image.network(
                  "https://picsum.photos/150",
                  width: 130,
                ),
                Image.network(
                  "https://picsum.photos/151",
                  width: 130,
                ),
              ],
            ),

            const SizedBox(height: 30),

            // 5. Botão com imagem
            ElevatedButton(
              onPressed: () {},
              child: Image.asset(
                "assets/botao.jpg",
                width: 80,
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
