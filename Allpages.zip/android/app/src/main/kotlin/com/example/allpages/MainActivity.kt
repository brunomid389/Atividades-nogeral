package com.example.allpages

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
