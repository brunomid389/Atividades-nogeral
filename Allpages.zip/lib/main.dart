import 'package:flutter/material.dart';

import 'screens/login.dart';
import 'screens/contato.dart';
import 'screens/privado.dart';
import 'screens/dados.dart';
import 'screens/gerenciamento.dart';
import 'screens/imagens.dart';
import 'screens/termos.dart';

void main() {
  runApp(const MeuApp());
}

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Minha Aplicação',
      debugShowCheckedModeBanner: false,

      // Tela inicial
      initialRoute: '/login',

      // Rotas da aplicação
      routes: {
        '/login': (context) => Login(),
        '/contato': (context) => Contato(),
        '/privado': (context) => Privado(),
        '/dados': (context) => Dados(),
        '/gerenciamento': (context) => Gerenciamento(),
        '/imagens': (context) => Imagens(),
        '/termos': (context) => Termos(),
      },
    );
  }
}
