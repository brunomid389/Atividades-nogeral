import 'package:flutter/material.dart';

class Imagens extends StatelessWidget {
  Imagens({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(),
      appBar: AppBar(
        title: Text("Menu"),
        backgroundColor: Colors.blue,
      ),
      body: ListView(
        children: [
          ListTile(
            title: Text("Login"),
            onTap: () => Navigator.pushNamed(context, "/login"),
          ),
          ListTile(
            title: Text("Contato"),
            onTap: () => Navigator.pushNamed(context, "/contato"),
          ),
          ListTile(
            title: Text("Dados"),
            onTap: () => Navigator.pushNamed(context, "/dados"),
          ),
          ListTile(
            title: Text("Gerenciamento"),
            onTap: () => Navigator.pushNamed(context, "/gerenciamento"),
          ),
          ListTile(
            title: Text("Imagens"),
            onTap: () => Navigator.pushNamed(context, "/imagens"),
          ),
          ListTile(
            title: Text("Privado"),
            onTap: () => Navigator.pushNamed(context, "/privado"),
          ),
          ListTile(
            title: Text("Termos"),
            onTap: () => Navigator.pushNamed(context, "/termos"),
          ),
        ],
      ),
    );
  }
}
