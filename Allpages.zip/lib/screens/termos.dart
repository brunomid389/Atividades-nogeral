import 'package:flutter/material.dart';

class Termos extends StatefulWidget {
  const Termos({super.key});

  @override
  State<Termos> createState() => _TermosState();
}

class _TermosState extends State<Termos> {
  bool aceitou = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Termos de Uso')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Expanded(
              child: SingleChildScrollView(
                child: Text(''),
              ),
            ),
            CheckboxListTile(
              value: aceitou,
              onChanged: (v) => setState(() => aceitou = v!),
              title: const Text('Aceito os termos'),
            ),
            ElevatedButton(
              onPressed: aceitou ? () {} : null,
              child: const Text('Continuar'),
            ),
          ],
        ),
      ),
    );
  }
}
