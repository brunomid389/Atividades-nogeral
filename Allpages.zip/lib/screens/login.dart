import 'package:flutter/material.dart';
import 'imagens.dart';

class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircleAvatar(radius: 35, child: Text("Logo")),
            const SizedBox(height: 20),
            const SizedBox(
              width: 200,
              child: TextField(
                decoration: InputDecoration(labelText: "Login"),
              ),
            ),
            const SizedBox(
              width: 200,
              child: TextField(
                decoration: InputDecoration(labelText: "Senha"),
                obscureText: true,
              ),
            ),
            Checkbox(
              value: false,
              onChanged: (v) {},
            ),
            const Text("Aceito os termos"),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Imagens(),
                  ),
                );
              },
              child: const Text("Entrar"),
            ),
          ],
        ),
      ),
    );
  }
}
