import 'package:flutter/material.dart';

class Privado extends StatelessWidget {
  const Privado({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Política de Privacidade')),
      body: const Padding(
        padding: EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Text(''),
        ),
      ),
    );
  }
}
