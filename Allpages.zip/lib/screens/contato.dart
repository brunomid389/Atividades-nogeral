import 'package:flutter/material.dart';

class Contato extends StatelessWidget {
  Contato({super.key});

  final nome = TextEditingController();
  final telefone = TextEditingController();
  final mensagem = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Contato')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
                controller: nome,
                decoration: const InputDecoration(labelText: 'Nome')),
            TextField(
                controller: telefone,
                decoration: const InputDecoration(labelText: 'Telefone')),
            TextField(
              controller: mensagem,
              decoration: const InputDecoration(labelText: 'Mensagem'),
              maxLines: 4,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {},
              child: const Text('Enviar'),
            ),
          ],
        ),
      ),
    );
  }
}
